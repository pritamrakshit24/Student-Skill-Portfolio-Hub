// server.js
const path = require("path");
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const dotenv = require("dotenv");
const multer = require("multer");
const fs = require("fs");

// Load environment variables
dotenv.config();

const app = express();

// Middleware
app.use(express.json());
app.use(cors());

// ---------- MongoDB Connect ----------
const uri = process.env.MONGODB_URI || "mongodb://127.0.0.1:27017/portfolio_hub";
mongoose
  .connect(uri, { autoIndex: true })
  .then(() => console.log("✅ MongoDB connected"))
  .catch((err) => {
    console.error("❌ MongoDB connection error:", err.message);
    process.exit(1);
  });

// ---------- Define Schema & Model ----------
const itemSchema = new mongoose.Schema(
  {
    title: { type: String, required: true },
    type: { type: String, enum: ["Image", "PDF", "Project"], required: true },
    description: { type: String },
    details: {
      filePath: { type: String },
      originalName: { type: String },
    },
  },
  { timestamps: true }
);

const PortfolioItem = mongoose.model("PortfolioItem", itemSchema);

// ---------- File Upload Setup ----------
const uploadDir = path.join(__dirname, "uploads");
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir);
}

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, uploadDir);
  },
  filename: function (req, file, cb) {
    const uniqueName = Date.now() + "-" + file.originalname;
    cb(null, uniqueName);
  },
});

const upload = multer({ storage });

// ---------- API Routes ----------

// 📥 Upload new item
app.post("/upload", upload.single("file"), async (req, res) => {
  try {
    const { title, type, description } = req.body;

    if (!title || !type) {
      return res.status(400).json({ message: "Title and type are required" });
    }

    const details = req.file
      ? {
          filePath: "/uploads/" + req.file.filename,
          originalName: req.file.originalname,
        }
      : {};

    const newItem = new PortfolioItem({ title, type, description, details });
    await newItem.save();

    res.status(201).json(newItem);
  } catch (err) {
    console.error("❌ Upload error:", err);
    res.status(500).json({ message: "Server error while uploading" });
  }
});

// 📄 Get all items
app.get("/api/items", async (req, res) => {
  try {
    const items = await PortfolioItem.find().sort({ createdAt: -1 });
    res.json(items);
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch items" });
  }
});

// 🗑 Delete an item
app.delete("/api/items/:id", async (req, res) => {
  try {
    const item = await PortfolioItem.findById(req.params.id);
    if (!item) return res.status(404).json({ message: "Item not found" });

    // Delete file from uploads folder if exists
    if (item.details?.filePath) {
      const filePath = path.join(__dirname, item.details.filePath);
      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
      }
    }

    await PortfolioItem.findByIdAndDelete(req.params.id);
    res.json({ message: "Item deleted" });
  } catch (err) {
    res.status(500).json({ error: "Failed to delete item" });
  }
});

// ---------- Serve Uploads & Frontend ----------
app.use("/uploads", express.static(uploadDir)); // serve uploaded files

const publicDir = path.join(__dirname, "public");
app.use(express.static(publicDir));

// Fallback to index.html for frontend routes
app.get("*", (_req, res) => {
  res.sendFile(path.join(publicDir, "index.html"));
});

// ---------- Start Server ----------
const port = process.env.PORT || 5000;
app.listen(port, () => console.log(`🚀 Server running on http://localhost:${port}`));